import React from 'react'

export const Place = () => {
  return (
    <div>
      <h1>Order Place successfully</h1>
      </div>
  )
} 

 